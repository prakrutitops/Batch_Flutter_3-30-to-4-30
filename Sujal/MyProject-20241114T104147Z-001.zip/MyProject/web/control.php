<?php
ob_start();
include_once 'model.php';


class MyControll extends model
{
    function __construct()
    {
        parent::__construct();
        $url = $_SERVER['PATH_INFO'];
        
        switch($url)
        {
            case '/tops':
                include_once 'header.php';
                //select country
                // $res = $this->Select_Data('country');

                //insert data
                if(isset($_POST['submit']))
                {
                    $uname = $_POST['uname'];
                    $email = $_POST['email'];
                    $pass = $_POST['password'];
                    $bio = $_POST['bio'];
                    $photo = $_FILES['photo']['name'];
                    $gen = $_POST['gender'];
                    $lan = $_POST['lan'];
                    $l = implode(",",$lan);
                    //$country = $_POST['country'];
                    move_uploaded_file($_FILES['photo']['tmp_name'],'upload/'.$_FILES['photo']['name']);
                    $data = array('uname'=>$uname,
                                'email'=>$email,
                                'pass'=>$pass,
                                'bio'=>$bio,
                                'photo'=>$photo,
                                'gender'=>$gen,
                                'lan'=>$l,
                               );
                        $this->Insert_Data('signup',$data);
                        echo "<script>alert('Data Inserted');</script>";
                }
                include_once 'signup.php';
                include_once 'footer.php';
                break;      
        }
    }

  
}
$obj = new MyControll;
ob_flush();
?>