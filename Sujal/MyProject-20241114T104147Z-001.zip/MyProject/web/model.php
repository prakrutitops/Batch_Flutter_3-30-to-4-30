<?php

class model
{
    public $con = '';
    function __construct()
    {
        $this->con = new mysqli("localhost","root","","prakruti");
    }
    function Insert_Data($tbl,$data)
    {
      //   Insert into register (name,pass,gebnder) values ('dj','hsdjd')
      $key = array_keys($data);
      $k = implode(",",$key);
      $val = array_values($data);
      $v = implode("','",$val);

      $sql = "INSERT INTO $tbl ($k) VALUES ('$v')";
      $q = $this->con->query($sql);
      return $q;
    }
}

?>