<?php include "../header.php" ?>

<?php

    if(isset($_GET['delete']))
    {
        $id=$_GET['delete'];

        $sql="delete from emp where id={$id}";
        $result=mysqli_query($con,$sql);
        header("Location: ../index.php");
    }

?>

<?php include "../footer.php" ?>