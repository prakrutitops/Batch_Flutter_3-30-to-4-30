<?php include "../header.php" ?>

<?php

    if(isset($_POST["create"]))
    {
        $unm=$_POST["user"];
        $email=$_POST["email"];
        $pass=$_POST["pass"];


        $sql="insert into emp (username,password,email) values ('{$unm}','{$pass}','{$email}')";
        $result=mysqli_query($con,$sql);

        if (!$result) 
        {
            echo "something went wrong ". mysqli_error($con);
        }

        else 
        {
           echo "<script type='text/javascript'>alert('User added successfully!')</script>";
           header("Location: ../index.php");

        }         

    }

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
        
<h1 class="text-center">Add User details </h1>
  <div class="container">
    <form action="" method="post">
      <div class="form-group">
        <label for="user" class="form-label">Username</label>
        <input type="text" name="user"  class="form-control">
      </div>

      <div class="form-group">
        <label for="email" class="form-label">Email ID</label>
        <input type="email" name="email"  class="form-control">
      </div>
    
      <div class="form-group">
        <label for="pass" class="form-label">Password</label>
        <input type="password" name="pass"  class="form-control">
      </div>    

      <div class="form-group">
        <input type="submit"  name="create" class="btn btn-primary mt-2" value="submit">
      </div>
    </form> 
  </div>



</body>
</html>
<?php include "../footer.php"?>