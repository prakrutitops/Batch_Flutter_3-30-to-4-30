<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<footer class="blockquote-footer fixed-bottom">Get more Details in IT <cite title="Source Title"><a href="https://www.tops-int.com/" target="_blank">Tops Technologies</a></cite></footer>


</body>
</html>